package com.example.virtualconnectingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

public class UsersActivity extends AppCompatActivity {
    private Toolbar mToolbar;
    private RecyclerView mUserslist;
    private DatabaseReference mUsersDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users);

        mUsersDatabase = FirebaseDatabase.getInstance().getReference().child("Users");

        mToolbar = findViewById(R.id.users_appbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("All Users");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        mUserslist = (RecyclerView) findViewById(R.id.users_list);
        mUserslist.setHasFixedSize(true);
        mUserslist.setLayoutManager(new LinearLayoutManager(this));
       // mMessagesList.setLayoutManager(mLinearLayout);
        mUserslist.addItemDecoration(new DividerItemDecoration(mUserslist.getContext(), DividerItemDecoration.VERTICAL));

    }

    @Override
    protected void onStart() {
        super.onStart();

        FirebaseRecyclerOptions<Users> options = new FirebaseRecyclerOptions.Builder<Users>()
                .setQuery(mUsersDatabase, Users.class)
                .build();
        FirebaseRecyclerAdapter<Users, UsersViewHolder> firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<Users, UsersViewHolder>(options) {


            @Override
            protected void onBindViewHolder(UsersViewHolder holder, int position, Users users) {
                holder.setName(users.getName());
                holder.setInterest(users.getInterest());
                holder.setImage(users.getImage());

                String user_id = getRef(position).getKey();
               holder.mView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent profileIntent = new Intent(UsersActivity.this, ProfileActivity.class);
                        profileIntent.putExtra("user_id", user_id);
                        startActivity(profileIntent);
                    }
                });

            }


            @NonNull
            @Override
            public UsersViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.users_single_layout, parent, false);
                return new UsersViewHolder(view);
            }

        };

        mUserslist.setAdapter(firebaseRecyclerAdapter);
        firebaseRecyclerAdapter.startListening();       //linking adapter to userslist

    }




    public class UsersViewHolder extends RecyclerView.ViewHolder {
        View mView;

        public UsersViewHolder(View itemView) {
            super(itemView);
            mView = itemView;       //mview is used for setting onclick to view items and also for adding values

        }

        public void setName(String name) {
            TextView mUsernameview = mView.findViewById(R.id.user_single_name);
            mUsernameview.setText(name);
        }

        public void setInterest(String interest) {
            TextView mUsersinterestView = mView.findViewById(R.id.user_single_interest);
            mUsersinterestView.setText(interest);
        }

        public void setImage(String image) {
            CircleImageView mUsersImage = mView.findViewById(R.id.user_single_image);
            if (!image.equals("default")) {
                Picasso.get().load(image).placeholder(R.mipmap.ic_profile).into(mUsersImage);
            }

        }

    }
}
