package com.example.virtualconnectingapp;

public class Conv {

    public boolean send;
    public long timestamp;

    public Conv(){

    }

    public boolean isSeen() {
        return send;
    }

    public void setSeen(boolean send) {
        this.send = send;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public Conv(boolean seen, long timestamp) {
        this.send = send;
        this.timestamp = timestamp;
    }
}
