package com.example.virtualconnectingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {
    private EditText mloginmail,mloginpassword;
    private Button mlogin_btn;
    private Toolbar mtoolbar;
    private ProgressDialog mloginprogress;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mloginmail = findViewById(R.id.Login_Email);
        mloginpassword = findViewById(R.id.Login_password);
        mlogin_btn = findViewById(R.id.Login_button);

        mAuth = FirebaseAuth.getInstance();

        mloginprogress = new ProgressDialog(this);

        mtoolbar = findViewById(R.id.Login_toolbar);
        setSupportActionBar(mtoolbar);
        getSupportActionBar().setTitle("Login");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        mlogin_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = mloginmail.getText().toString();
                String password = mloginpassword.getText().toString();

                if(!TextUtils.isEmpty(email)|| !TextUtils.isEmpty(password))
                {
                    mloginprogress.setTitle("Logging In");
                    mloginprogress.setMessage("please wait while we are checking your credentials");
                    mloginprogress.setCanceledOnTouchOutside(false);
                    mloginprogress.show();
                    loginUser(email,password);
                }
            }
        });

    }

    private void loginUser(String email, String password) {
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull  Task<AuthResult> task) {

                        if(task.isSuccessful())
                        {
                            mloginprogress.dismiss();
                            Intent mainIntent = new Intent(LoginActivity.this,MainActivity.class);
                            mainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(mainIntent);
                            finish();
                        }
                        else
                        {
                            mloginprogress.dismiss();
                            String message = task.getException().getMessage();
                            Toast.makeText(LoginActivity.this,"Error Occured:"+message,Toast.LENGTH_SHORT).show();
                        }

                    }
                });

    }
}