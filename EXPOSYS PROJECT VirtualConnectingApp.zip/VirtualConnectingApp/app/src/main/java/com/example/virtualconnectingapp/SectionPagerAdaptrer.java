package com.example.virtualconnectingapp;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class SectionPagerAdaptrer extends FragmentPagerAdapter {
    public SectionPagerAdaptrer(@NonNull FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {

        switch (position){
           // case 0 :
           /*     Requests_Fragment requests_fragment = new Requests_Fragment();
                return requests_fragment;
            case 1:
                Chats_Fragment chats_fragment = new Chats_Fragment();
                return  chats_fragment;*/
            case 0:
                Friends_Fragment friends_fragment = new Friends_Fragment();
                return  friends_fragment;
            default:
                return  null;
        }
    }

    @Override
    public int getCount() {
        return 1;
    }
    public  CharSequence getPageTitle(int position){
        switch (position){
           /* case 0:
                return  "REQUESTS";
            case 0:
                return  "CHATS";*/
            case 0:
                return  "FRIENDS";
            default:
                return null;
        }
    }
}
