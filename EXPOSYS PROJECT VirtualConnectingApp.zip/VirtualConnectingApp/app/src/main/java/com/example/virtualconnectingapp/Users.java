package com.example.virtualconnectingapp;

public class Users {
    public  String name;
    public String interest;
    public String image;

    public  Users()
    {

    }
    public Users(String name,String image,String interest)
    {
        this.name = name;
        this.interest = interest;
        this.image = image;
    }

    public String  getName()
    {
        return name;
    }
    public void setName(String name)
    {
        this.name = name;
    }
    public String  getImage()
    {
        return image;
    }
    public void  setImage(String image)
    {
        this.image= image;
    }
    public String  getInterest()
    {
        return interest;
    }
    public void setInterest(String interest)
    {
        this.interest = interest;
    }
}
