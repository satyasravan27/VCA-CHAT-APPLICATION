package com.example.virtualconnectingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class ProfileActivity extends AppCompatActivity {
        private TextView mProfileName,mProfileInterest,mprofileFriendsCount;
        private ImageView mProfileImage;
        private Button mProfileSendreqbtn,mDeclinedbtn;
        private ProgressDialog mProgressDialog;

        //Database Reference
    private DatabaseReference mUsersDataBase;

    private FirebaseUser mCurrent_user;

    private String mcurrent_state;

    private DatabaseReference mFriendRequestDatabase;

    private  DatabaseReference mFriendDatabase;
    private DatabaseReference mNotificationDatabase;

        @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        String user_id = getIntent().getStringExtra("user_id");

        mUsersDataBase = FirebaseDatabase.getInstance().getReference().child("Users").child(user_id);
        mFriendDatabase = FirebaseDatabase.getInstance().getReference().child("Friends");
        mcurrent_state = "not_friends";
        mFriendRequestDatabase =FirebaseDatabase.getInstance().getReference().child("Friend_req");
        mNotificationDatabase = FirebaseDatabase.getInstance().getReference().child("notifications");
        mCurrent_user = FirebaseAuth.getInstance().getCurrentUser();

        mProgressDialog= new ProgressDialog(this);
        mProgressDialog.setTitle("Loading User Data");
        mProgressDialog.setMessage("Please wait While we load the User data");
        mProgressDialog.setCanceledOnTouchOutside(false);
        mProgressDialog.show();




        mProfileName = findViewById(R.id.profile_display_name);
        mProfileInterest =findViewById(R.id.profile_Interest);
        //mprofileFriendsCount = findViewById(R.id.profile_totalfriends);
        mProfileImage = findViewById(R.id.profile_Image);
        mProfileSendreqbtn =findViewById(R.id.profile_send_req_btn);
        mDeclinedbtn = findViewById(R.id.profile_decline_req_btn);
            mDeclinedbtn.setVisibility(View.INVISIBLE);
            mDeclinedbtn.setEnabled(false);

        mUsersDataBase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String display_name = snapshot.child("name").getValue().toString();
                String interest = snapshot.child("interest").getValue().toString();
                String Image = snapshot.child("image").getValue().toString();
                mProfileName.setText(display_name);
                mProfileInterest.setText(interest);
                if (!Image.equals("default")) {
                    Picasso.get().load(Image).placeholder(R.mipmap.ic_profile).into(mProfileImage);
                    mProgressDialog.dismiss();
                } else {
                    mProgressDialog.hide();
                }

                //--------FRIENDS LIST / REQUEST FEATURE---------//


                mFriendRequestDatabase.child(mCurrent_user.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.hasChild(user_id)){
                            String req_type = snapshot.child(user_id).child("request_type").getValue().toString();
                            if(req_type.equals("received")){
                                mcurrent_state = "req_received";
                                mProfileSendreqbtn.setText("Accept Friend Request ");
                                mDeclinedbtn.setVisibility(View.VISIBLE);
                                mDeclinedbtn.setEnabled(true);
                                //Toast.makeText(ProfileActivity.this,"You Accepted",Toast.LENGTH_SHORT).show();
                            }
                            else if(req_type.equals("sent")) {
                                mcurrent_state = "req_sent";
                                mProfileSendreqbtn.setText("Cancel Friend Request");
                                mDeclinedbtn.setVisibility(View.INVISIBLE);
                                mDeclinedbtn.setEnabled(false);
                            }
                            mProgressDialog.dismiss();
                            }else{
                                mFriendDatabase.child(mCurrent_user.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull  DataSnapshot datasnapshot) {
                                        if(datasnapshot.hasChild(user_id)){
                                            mcurrent_state="friends";
                                            mProfileSendreqbtn.setText("UnFriend this person");
                                            mDeclinedbtn.setVisibility(View.INVISIBLE);
                                            mDeclinedbtn.setEnabled(false);

                                            Toast.makeText(ProfileActivity.this,"sucess",Toast.LENGTH_SHORT).show();
                                        }
                                       mProgressDialog.dismiss();
                                    }

                                    @Override
                                    public void onCancelled(@NonNull  DatabaseError error) {
                                        mProgressDialog.dismiss();
                                    }
                                });
                            }



                    }

                    @Override
                    public void onCancelled(@NonNull  DatabaseError error) {

                    }
                });



            }

            @Override
            public void onCancelled(@NonNull  DatabaseError error) {

            }
        });

        mProfileSendreqbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mProfileSendreqbtn.setEnabled(false);
                    ////------------NOT FRIENDS STATE-------------------////
                if(mcurrent_state.equals("not_friends")){

                    mFriendRequestDatabase.child(mCurrent_user.getUid()).child(user_id).child("request_type")
                            .setValue("sent").addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful())
                            {
                             mFriendRequestDatabase.child(user_id).child(mCurrent_user.getUid()).child("request_type")
                             .setValue("received").addOnSuccessListener(new OnSuccessListener<Void>() {
                                 @Override
                                 public void onSuccess(Void unused) {
                                     mProfileSendreqbtn.setEnabled(true);
                                     mcurrent_state="req_sent";
                                     mProfileSendreqbtn.setText("Cancel Friend Request");
                                     mDeclinedbtn.setVisibility(View.INVISIBLE);
                                     mDeclinedbtn.setEnabled(false);
                                     mProgressDialog.dismiss();
                                     //Toast.makeText(ProfileActivity.this,"Request sent Succesfully",Toast.LENGTH_SHORT).show();
                                 }
                             });
                            }
                            else
                            {
                                mProgressDialog.dismiss();
                                String message = task.getException().getMessage();
                                Toast.makeText(ProfileActivity.this,"Error Occured"+message,Toast.LENGTH_SHORT).show();
                            }
                            mProfileSendreqbtn.setEnabled(true);
                        }
                    });

                }

                //------CANCEL REQUEST STATE-------//
                if(mcurrent_state.equals("req_sent")){
                    mFriendRequestDatabase.child(mCurrent_user.getUid()).child(user_id).removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void unused) {
                            mFriendRequestDatabase.child(user_id).child(mCurrent_user.getUid()).removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void unused) {
                                    mProfileSendreqbtn.setEnabled(true);
                                    mcurrent_state="not_friends";
                                    mProfileSendreqbtn.setText("Send Friend Request");
                                    mDeclinedbtn.setVisibility(View.INVISIBLE);
                                    mDeclinedbtn.setEnabled(false);




                                }
                            });
                        }
                    });
                }
                //------------ACCEPT FRIEND REQUEST-----//
                if(mcurrent_state.equals("req_received")){
                    String currentDate = DateFormat.getDateInstance().format(new Date());
                    mFriendDatabase.child(mCurrent_user.getUid()).child(user_id).setValue(currentDate).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void unused) {
                            mFriendDatabase.child(user_id).child(mCurrent_user.getUid()).setValue(currentDate).addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void unused) {

                                    mFriendRequestDatabase.child(mCurrent_user.getUid()).child(user_id).removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void unused) {
                                            mFriendRequestDatabase.child(user_id).child(mCurrent_user.getUid()).removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
                                                @Override
                                                public void onSuccess(Void unused) {
                                                    mProfileSendreqbtn.setEnabled(true);
                                                    mcurrent_state="friends";
                                                    mProfileSendreqbtn.setText("UnFriend this person");
                                                    mDeclinedbtn.setVisibility(View.INVISIBLE);
                                                    mDeclinedbtn.setEnabled(false);




                                                }
                                            });
                                        }
                                    });

                                }
                            });
                        }
                    });
                }

                if (mcurrent_state .equals("friends")){
                   /* Map unfriendMap = new HashMap();
                    unfriendMap.put("Friends/"+mCurrent_user.getUid()+"/"+user_id,null);
                    unfriendMap.put("Friends/"+ user_id+ "/"+mCurrent_user.getUid(),null);*/
                    mFriendDatabase.child(mCurrent_user.getUid()).child(user_id).setValue(null).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful()){
                                mFriendDatabase.child(user_id).child(mCurrent_user.getUid()).setValue(null).addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void unused) {
                                        mProfileSendreqbtn.setEnabled(true);
                                        mcurrent_state="not_friends";
                                        mProfileSendreqbtn.setText("Send Friend Request");

                                    }
                                });
                            }
                            else{
                                Toast.makeText(ProfileActivity.this,"error occured",Toast.LENGTH_SHORT).show();
                            }
                        }
                    });


                }


            }
        });

        mDeclinedbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mProfileSendreqbtn.setEnabled(false);
                //------Decline REQUEST STATE-------//
                if(mcurrent_state.equals("req_received")){
                    mFriendRequestDatabase.child(mCurrent_user.getUid()).child(user_id).removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void unused) {
                            mFriendRequestDatabase.child(user_id).child(mCurrent_user.getUid()).removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void unused) {
                                   mProfileSendreqbtn.setEnabled(true);
                                    mcurrent_state="not_friends";
                                    mProfileSendreqbtn.setText("Send Friend Request");
                                    mDeclinedbtn.setVisibility(View.VISIBLE);
                                    mDeclinedbtn.setEnabled(true);




                                }
                            });
                        }
                    });
                }

            }
        });

    }
}